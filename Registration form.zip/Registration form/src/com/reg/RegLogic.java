package com.reg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class RegLogic
 */
public class RegLogic extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegLogic() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		String i=request.getParameter("flag");
		
		String fn=request.getParameter("first_name");
		
		try{
			
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("dirver found");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/reg","root","nikhil");
         System.out.println("conection found1");
			if(i.equals("SUBMIT")){
				System.out.println("wellcome to regJdbc page");
				String s4=request.getParameter("fname");
				String s5=request.getParameter("lname");
				String s6=request.getParameter("email");
				long s7=Long.parseLong(request.getParameter("phone"));
				String s8=request.getParameter("city");
				
			PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?,?,?)");
			
			ps.setString(1,s4);
			ps.setString(2,s5);
			ps.setString(3,s6);
			ps.setLong(4, s7);
			ps.setString(5,s8);
			
			ps.executeUpdate();
			System.out.println("update Sucess");
			ps.close();}
			else if(i.equals("delete")){
			
				PreparedStatement ps=con.prepareStatement("delete from student where first_name=?");
				
				ps.setString(1,fn);
				ps.executeUpdate();
				System.out.println("delete Sucess");
				ps.close();
			}else if(i.equals("edit")){
				
				Statement stm=con.createStatement();
			 	ResultSet rs=stm.executeQuery("select * from student where first_name="+'"'+fn+'"');
			 	
				while(rs.next()){
					String first_name=rs.getString(1);
					String last_name=rs.getString(2);
					String email=rs.getString(3);
					long phone=rs.getLong(4);
					String location=rs.getString(5);
					
					 HttpSession session = request.getSession();
					    session.setAttribute("fn", first_name);
					    session.setAttribute("ln", last_name);
					/*request.setAttribute("fname", "nik");
					System.out.println(first_name);
					request.setAttribute("lname", last_name);*/
			
				}
			}
			
			RequestDispatcher rd=request.getRequestDispatcher("RegPage.jsp");
			rd.forward(request, response);
			
		}
			catch(Exception e){
			System.out.println(e);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
