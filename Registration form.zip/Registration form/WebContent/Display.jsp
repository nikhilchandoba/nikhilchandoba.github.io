<%@ page language="java" contentType="text/html; charset=ISO-8859-1"
    pageEncoding="ISO-8859-1"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<%@ page import= "java.io.IOException"%>
<%@ page import= "java.io.PrintWriter"%>
<%@ page import="java.sql.Connection"%>
<%@ page import="java.sql.Statement"%>
<%@ page import="java.sql.*"%>
<%@ page import= "java.sql.DriverManager"%>
<%@ page import="java.sql.PreparedStatement" %>
<%@ page import ="javax.servlet.ServletException" %>
<%@ page import ="javax.servlet.http.HttpServlet" %>
<%@ page import ="javax.servlet.http.HttpServletRequest" %>
<%@page import= "javax.servlet.http.HttpServletResponse" %>
<%@page import= "javax.servlet.http.HttpSession" %>
<table border="4">
<tr><th colspan="5" >book shell</th></tr>
<tr><th >First Name</th><th >last Name</th><th>email</th><th>Phone</th><th>Location</th></tr>

		 
	<%try{
		
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("dirver found");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/reg","root","nikhil");
     System.out.println("conection found");
 	Statement stm=con.createStatement();
 	ResultSet rs=stm.executeQuery("select * from student");
	while(rs.next()){
		String first_name=rs.getString(1);
		String last_name=rs.getString(2);
		String email=rs.getString(3);
		long phone=rs.getLong(4);
		String location=rs.getString(5);
	
	%>
	
	<tr><th rowspan="1"><%= first_name%></th>
	 	
<th rowspan="1"><%= last_name%></th>
<th rowspan="1"> <%=email%></th>
<th rowspan="1"> <%=phone%></th>
<th rowspan="1"> <%=location%></th></tr> 
	<%}
	}catch(Exception e){
		System.out.println(e);
		} %>
	}
</table>

</body>
</html>