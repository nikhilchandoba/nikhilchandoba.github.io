import java.util.Scanner;
import java.util.StringTokenizer;

class SplitString {
public static void main(String [] args){
	Scanner s=new Scanner(System.in);
	System.out.println("Enter the String value");
	String st=s.nextLine();
	//String st ="hi Nikhil ,where are u from? from india! ha ha ha ha ha ha.nice";
	
	StringTokenizer m = new StringTokenizer(st,",?!.");
	System.out.println("count="+m.countTokens());
	
	int max=0;
	while(m.hasMoreTokens()){
		String k=m.nextToken();
		System.out.println(k);
		StringTokenizer l = new StringTokenizer(k);	
		int count=l.countTokens();
		System.out.println(count);
		
		if(count>max){
			max=count;
		}
		
	}System.out.println("maximum no="+max);
	
	
}
}
